#!/usr/bin/env python3
"""
anonymize_real_slack_leveldb.py

Reads the REAL Slack Local Storage LevelDB (localConfig_v2 and
activitySession_<teamId> keys only, every recoverable historical version),
and writes a new, physically valid LevelDB containing the same structure,
version history, and record states - but with every identifying value
(team/user/session IDs, workspace names/urls/domains, tokens, timestamps)
replaced by a deterministic fake equivalent. No real identifying value is
ever written to the output. A final regex sweep confirms none leaked
through fields this script didn't explicitly model.

Real values are read into memory to build the substitution maps and are
never printed or logged.
"""
import sys
import io
import json
import random
import re
import hashlib
import importlib.util
import pathlib

import plyvel

sys.path.insert(0, "/tmp")
spec = importlib.util.spec_from_file_location("ccl_leveldb", "/tmp/slacksploit_ccl_leveldb.py")
ccl_leveldb = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ccl_leveldb)

ORIGIN = "https://app.slack.com"
_META_PREFIX = b"META:"

# ---- Chromium marker-byte string encoding, matching what real Slack used ----
# (confirmed: marker 0x01 = single-byte/latin1, for both keys and values here)

def decode(b):
    if not b:
        return ""
    marker, rest = b[0:1], b[1:]
    if marker == b"\x00":
        return rest.decode("utf-16-le", "replace")
    try:
        return rest.decode("latin1")
    except Exception:
        return rest.decode("utf-8", "replace")


def encode(text):
    return b"\x01" + text.encode("latin1", "replace")


def make_key(user_key_str):
    return b"_" + ORIGIN.encode("utf-8") + b"\x00" + encode(user_key_str)


# ---------------------------------------------------------------------------
# Deterministic fake-value generation

_id_map = {}
_token_map = {}
_domain_map = {}
_name_map = {}
_session_id_map = {}
_real_secrets = []  # every real string we're substituting away, for the final sweep

ALNUM = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
ALNUM_UPPER = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

def _seeded_rand(seed_str):
    h = hashlib.sha256(seed_str.encode()).digest()
    return random.Random(h)

def fake_slack_id(real_id):
    if not real_id:
        return real_id
    if real_id in _id_map:
        return _id_map[real_id]
    prefix = real_id[0] if real_id[0] in "TUCDG" else "T"
    r = _seeded_rand("id:" + real_id)
    fake = prefix + "".join(r.choice(ALNUM_UPPER) for _ in range(len(real_id) - 1))
    _id_map[real_id] = fake
    _real_secrets.append(real_id)
    return fake

def fake_token(real_token):
    if not real_token:
        return real_token
    if real_token in _token_map:
        return _token_map[real_token]
    r = _seeded_rand("token:" + real_token)
    m = re.match(r"(xox[a-z])-", real_token)
    prefix = m.group(1) if m else "xoxc"
    seg = lambda n: "".join(r.choice("0123456789") for _ in range(n))
    hexseg = "".join(r.choice("0123456789abcdef") for _ in range(64))
    fake = f"{prefix}-{seg(13)}-{seg(13)}-{seg(13)}-{hexseg}"
    _token_map[real_token] = fake
    _real_secrets.append(real_token)
    return fake

FAKE_COMPANY_WORDS = ["Corp", "Labs", "Collective", "Studio", "Group", "Works", "Guild", "Union"]
FAKE_ADJ = ["Synth", "Fable", "North", "Vertex", "Cobalt", "Ember", "Quartz", "Delta"]

def fake_name(real_name):
    if not real_name:
        return real_name
    if real_name in _name_map:
        return _name_map[real_name]
    r = _seeded_rand("name:" + real_name)
    fake = f"{r.choice(FAKE_ADJ)} {r.choice(FAKE_COMPANY_WORDS)}"
    _name_map[real_name] = fake
    _real_secrets.append(real_name)
    return fake

def fake_domain(real_domain):
    if not real_domain:
        return real_domain
    if real_domain in _domain_map:
        return _domain_map[real_domain]
    r = _seeded_rand("domain:" + real_domain)
    fake = (r.choice(FAKE_ADJ) + "-" + r.choice(FAKE_COMPANY_WORDS)).lower()
    _domain_map[real_domain] = fake
    _real_secrets.append(real_domain)
    return fake

def fake_session_id(real_sid):
    if not real_sid:
        return real_sid
    if real_sid in _session_id_map:
        return _session_id_map[real_sid]
    r = _seeded_rand("sess:" + real_sid)
    fake = "".join(r.choice(ALNUM) for _ in range(len(real_sid)))
    _session_id_map[real_sid] = fake
    _real_secrets.append(real_sid)
    return fake


TIME_SHIFT_SECONDS = random.Random("global-time-shift").randint(-60 * 60 * 24 * 240, -60 * 60 * 24 * 10)

def shift_epoch_seconds(v):
    if not isinstance(v, (int, float)) or not v:
        return v
    return v + TIME_SHIFT_SECONDS

def shift_epoch_ms(v):
    if not isinstance(v, (int, float)) or not v:
        return v
    return v + TIME_SHIFT_SECONDS * 1000

def shift_iso8601(v):
    if not v or not isinstance(v, str):
        return v
    from datetime import datetime, timezone, timedelta
    try:
        dt = datetime.fromisoformat(v.replace("Z", "+00:00"))
    except ValueError:
        return v
    dt = dt + timedelta(seconds=TIME_SHIFT_SECONDS)
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def transform_url(real_url, real_domain_for_map):
    if not real_url:
        return real_url
    fake_dom = fake_domain(real_domain_for_map)
    return re.sub(re.escape(real_domain_for_map), fake_dom, real_url)


def transform_team(team_obj):
    """Transform the non-ID-shaped fields of one team dict from
    localConfig_v2's teams/prevTeams map. Deliberately leaves "id",
    "user_id", and any other ID-shaped strings (e.g. inside lastRoute)
    untouched here - those are caught in a single comprehensive
    _deep_remap() pass by the caller, so a real ID only ever gets mapped
    once (mapping an already-fake ID again would corrupt the substitution
    and poison the leak-detection safety net)."""
    out = dict(team_obj)
    real_domain = out.get("domain", "")
    if "name" in out:
        out["name"] = fake_name(out["name"])
    if "domain" in out:
        out["domain"] = fake_domain(out["domain"])
    if "url" in out:
        out["url"] = transform_url(out["url"], real_domain)
    if "token" in out:
        out["token"] = fake_token(out["token"])
    if "versionDataTs" in out:
        out["versionDataTs"] = shift_epoch_seconds(out["versionDataTs"])
    if "mostRecentlyUsedDate" in out:
        out["mostRecentlyUsedDate"] = shift_iso8601(out["mostRecentlyUsedDate"])
    if real_domain:
        out = _domain_only_remap(out, real_domain)
    return out


def _domain_only_remap(obj, real_domain):
    """Like _deep_remap but only substitutes the given real domain string -
    used inside transform_team (before IDs are touched) so icon/CDN URLs
    embedding the real domain get fixed without also running the ID regex
    over still-real ID fields at this stage."""
    if isinstance(obj, dict):
        return {k: _domain_only_remap(v, real_domain) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_domain_only_remap(v, real_domain) for v in obj]
    if isinstance(obj, str) and real_domain and real_domain in obj:
        return obj.replace(real_domain, fake_domain(real_domain))
    return obj


_ID_RE = re.compile(r"\b([TUCDG][A-Z0-9]{7,10})\b")

def _deep_remap(obj, real_domain=""):
    if isinstance(obj, dict):
        return {k: _deep_remap(v, real_domain) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_deep_remap(v, real_domain) for v in obj]
    if isinstance(obj, str):
        s = obj
        if real_domain:
            s = re.sub(re.escape(real_domain), fake_domain(real_domain), s)
        s = _ID_RE.sub(lambda m: fake_slack_id(m.group(1)), s)
        return s
    return obj


def transform_local_config(config, real_domains):
    """Transform localConfig_v2. Dict KEYS (team IDs in teams/prevTeams) are
    remapped explicitly here since _deep_remap only recurses into values.
    Every ID-shaped VALUE anywhere in the object - team.id, team.user_id,
    lastActiveTeamId, orderedTeamIds entries, or anything in a field this
    script doesn't know about (view-history lists, etc.) - is left as the
    real value from transform_team() and caught in exactly ONE trailing
    _deep_remap() pass below, so no value is ever mapped twice."""
    out = dict(config)
    for bucket in ("teams", "prevTeams"):
        if bucket in out and isinstance(out[bucket], dict):
            new_bucket = {}
            for tid, team in out[bucket].items():
                if isinstance(team, dict):
                    real_domains.add(team.get("domain", ""))
                    new_bucket[fake_slack_id(tid)] = transform_team(team)
                else:
                    new_bucket[fake_slack_id(tid)] = team
            out[bucket] = new_bucket
    # Single comprehensive pass: catches lastActiveTeamId, orderedTeamIds,
    # team.id, team.user_id, and any ID-shaped string in an unrecognized
    # field - all in one go, so nothing gets double-mapped.
    out = _deep_remap(out)
    return out


def transform_sessions(sessions_obj):
    out = {}
    for sid, sess in sessions_obj.items():
        if not isinstance(sess, dict):
            out[fake_session_id(sid)] = sess
            continue
        new_sess = dict(sess)
        if "id" in new_sess:
            new_sess["id"] = fake_session_id(new_sess["id"])
        if "startTime" in new_sess:
            new_sess["startTime"] = shift_epoch_ms(new_sess["startTime"])
        if "lastActivity" in new_sess:
            new_sess["lastActivity"] = shift_epoch_ms(new_sess["lastActivity"])
        if "lastLogged" in new_sess:
            new_sess["lastLogged"] = shift_epoch_ms(new_sess["lastLogged"])
        out[fake_session_id(sid)] = new_sess
    return out


def repair_sweep(text):
    """Global find-and-replace using every mapping built so far, as a catch-all
    for fields the targeted transforms don't know about (e.g. unexpected
    top-level keys). Longest secrets first, so no partial-substring collisions."""
    combined = {}
    combined.update(_id_map)
    combined.update(_token_map)
    combined.update(_name_map)
    combined.update(_domain_map)
    combined.update(_session_id_map)
    for secret in sorted(combined, key=len, reverse=True):
        if secret and secret in text:
            text = text.replace(secret, combined[secret])
    return text


def final_sweep(text, context=""):
    """Defense in depth: assert no real secret substring survived."""
    for secret in _real_secrets:
        if secret and len(secret) >= 4 and secret in text:
            category = (
                "id" if secret in _id_map else
                "token" if secret in _token_map else
                "name" if secret in _name_map else
                "domain" if secret in _domain_map else
                "session_id" if secret in _session_id_map else
                "unknown"
            )
            idx = text.index(secret)
            snippet_start = max(0, idx - 30)
            print(f"    LEAK category={category} len={len(secret)} context={context}")
            print(f"    surrounding (secret itself redacted): "
                  f"{text[snippet_start:idx]!r} <<SECRET>> {text[idx+len(secret):idx+len(secret)+30]!r}")
            raise RuntimeError(f"Real value leaked into output (length {len(secret)}, category {category})")


# ---------------------------------------------------------------------------

def read_real_records(folder):
    db = ccl_leveldb.RawLevelDb(folder)
    records = []
    for record in db.iterate_records_raw():
        raw_key = record.user_key
        if not raw_key or raw_key.startswith(_META_PREFIX) or not raw_key.startswith(b"_"):
            continue
        origin_bytes, sep, key_bytes = raw_key[1:].partition(b"\x00")
        if not sep:
            continue
        origin = origin_bytes.decode("utf-8", "replace")
        if "slack.com" not in origin.lower():
            continue
        key = decode(key_bytes)
        if key != "localConfig_v2" and not key.startswith("activitySession_"):
            continue
        records.append({
            "key": key,
            "value_bytes": record.value,
            "seq": record.seq,
            "state": record.state.name,
        })
    db.close()
    records.sort(key=lambda r: r["seq"])
    return records


def build(in_folder, out_dir):
    real_records = read_real_records(in_folder)
    print(f"[*] Read {len(real_records)} real records (localConfig_v2 / activitySession_*) "
          f"across {len(set(r['key'] for r in real_records))} distinct keys.")

    out_dir = pathlib.Path(out_dir)
    leveldb_path = out_dir / "Slack" / "Local Storage" / "leveldb"
    if leveldb_path.exists():
        import shutil
        shutil.rmtree(leveldb_path)
    leveldb_path.mkdir(parents=True, exist_ok=True)

    db = plyvel.DB(str(leveldb_path), create_if_missing=True)
    real_domains = set()

    written = 0
    for r in real_records:
        fake_key = key_for_team = r["key"]
        if r["state"] == "Deleted":
            # preserve team id inside the key itself too
            if fake_key.startswith("activitySession_"):
                real_tid = fake_key[len("activitySession_"):]
                fake_key = "activitySession_" + fake_slack_id(real_tid)
            db.delete(make_key(fake_key))
            written += 1
            continue

        real_value_text = decode(r["value_bytes"])
        try:
            parsed = json.loads(real_value_text)
        except (ValueError, TypeError):
            continue  # not JSON, not one of our two target shapes - skip

        if r["key"] == "localConfig_v2":
            transformed = transform_local_config(parsed, real_domains)
        else:
            real_tid = r["key"][len("activitySession_"):]
            fake_key = "activitySession_" + fake_slack_id(real_tid)
            transformed = transform_sessions(parsed)

        out_text = json.dumps(transformed, ensure_ascii=False)
        out_text = repair_sweep(out_text)
        final_sweep(out_text, context=f"key={r['key']} seq={r['seq']}")
        final_sweep(fake_key, context=f"key={r['key']} seq={r['seq']} (key itself)")

        db.put(make_key(fake_key), encode(out_text))
        written += 1

    # Force a flush into real .ldb/.sst table files (see note in
    # build_synthetic_slack_leveldb.py - a fresh DB's first compaction has
    # nothing to merge against, so it serializes everything in the memtable
    # without dropping any historical version; verified below by re-running
    # the same read path and checking record counts match).
    db.compact_range()
    db.close()
    print(f"[*] Wrote {written} anonymized records to {leveldb_path}")
    print(f"[*] {len(_id_map)} IDs, {len(_token_map)} tokens, {len(_name_map)} names, "
          f"{len(_domain_map)} domains, {len(_session_id_map)} session IDs remapped.")
    print(f"[*] Timestamp shift applied: {TIME_SHIFT_SECONDS} seconds "
          f"(~{TIME_SHIFT_SECONDS / 86400:.1f} days)")
    return leveldb_path


if __name__ == "__main__":
    in_folder = sys.argv[1] if len(sys.argv) > 1 else "/root/forensic-synth/input/real_slack_leveldb"
    out_dir = sys.argv[2] if len(sys.argv) > 2 else "/root/forensic-synth/output/anonymized_slack"
    build(in_folder, out_dir)
