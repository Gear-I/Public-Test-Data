# Anonymized Slack Desktop Local Storage fixture (derived from real usage)

Test data for [DLEAPP PR #67](https://github.com/abrignoni/DLEAPP/pull/67)
(`slackWorkspaces.py` / `slackSessions.py`). Unlike the earlier
fully-synthetic-from-scratch fixture, this one started from a **real**
Slack Local Storage LevelDB and was **anonymized** — every identifying
value was found and replaced, but the surrounding structure (field names,
nesting, which fields Slack's current client actually populates) is real,
which the earlier hand-authored version couldn't fully capture.

## What was replaced

Every occurrence of, across all 6 keys and 12 recovered record versions:

- Team IDs, user IDs, channel/DM/view-state IDs (anything matching Slack's
  `[TUCDG][A-Z0-9]{7,10}` ID shape, wherever it appeared — including nested
  fields like `lastViewState` that weren't specifically anticipated)
- Session tokens (`token`) — fully replaced with fabricated
  structurally-valid tokens, not just masked
- Workspace names, domains, and URLs
- Session IDs (`activitySession_*` entries)
- All timestamps — shifted by one consistent random offset (preserves
  relative ordering and exact deltas between events, removes the real
  calendar dates)

Untouched: non-identifying structural/cosmetic values (theme colors,
`is_unified_user_client_enabled`, `user_locale`, UI view-type literals like
`"ChannelList"`, Slack's own CDN hostnames).

## How it was verified

Two independent checks, both must pass before this was packaged:

1. **Generation-time repair + assert** (`anonymize_fixture.py`): after
   transforming each record, a global find-and-replace sweep using every
   mapping built so far runs first, then a hard assertion checks no known
   real secret substring survived. An early version of this script caught
   a real ID leaking through a `lastViewState` field this script hadn't
   explicitly modeled — that's what the sweep exists for.
2. **Independent second-pass verification** (`verify_fixture.py`): re-reads
   the real input from scratch to rebuild a real answer key (team/user IDs,
   tokens, names, domains, session IDs — a broader net than the maps the
   generator used), re-reads the *output* fresh with `ccl_leveldb`'s raw
   scanner, and confirms none of ~50 known real secrets appear anywhere in
   the raw key or value bytes. Also confirms every non-tombstone value
   still parses as valid JSON after transformation.

Both passed clean on this fixture: 12/12 records recovered with correct
states, 0 leaks against every known real secret.

## What's here

```
Slack/Local Storage/leveldb/   <- the anonymized fixture: real, physically
                                   valid LevelDB files
anonymize_fixture.py           <- the transform pipeline (does not include
                                   the real source data)
verify_fixture.py              <- independent leak-detection pass
```

## Record shape (safe to state — these counts, not the values, are fixed)

- `localConfig_v2`: 4 recovered versions, all `Live`
- 5 `activitySession_<teamId>` keys, version counts and states varying
  per workspace (including a real historical pattern of repeated updates
  to the most active workspace)
- 12 total raw records across the 6 distinct keys

Exact team/user/session ID values are randomized per generation run (seeded
from the real input, which isn't included here), so don't hardcode them in
tests — assert on structure and counts instead.
