#!/usr/bin/env python3
"""
Independent second-pass verification of the anonymized Slack LevelDB:
1. Re-reads the REAL input to know every real secret value.
2. Re-reads the OUTPUT (anonymized) LevelDB fresh, independent of the
   generation script's own in-process bookkeeping.
3. Confirms every output record parses as JSON (or is a clean tombstone),
   and asserts none of the real secret strings appear anywhere in the
   output's raw bytes - not just the JSON values, the raw key/value bytes.
4. Prints only structural counts - never real or fake content.
"""
import sys
import json
import importlib.util

sys.path.insert(0, "/tmp")
spec = importlib.util.spec_from_file_location("ccl_leveldb", "/tmp/slacksploit_ccl_leveldb.py")
ccl_leveldb = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ccl_leveldb)

_META_PREFIX = b"META:"


def decode(b):
    if not b:
        return ""
    marker, rest = b[0:1], b[1:]
    if marker == b"\x00":
        return rest.decode("utf-16-le", "replace")
    try:
        return rest.decode("latin1")
    except Exception:
        return rest.decode("utf-8", "replace")


def read_raw(folder):
    db = ccl_leveldb.RawLevelDb(folder)
    out = []
    for record in db.iterate_records_raw():
        raw_key = record.user_key
        if not raw_key or raw_key.startswith(_META_PREFIX) or not raw_key.startswith(b"_"):
            continue
        origin_bytes, sep, key_bytes = raw_key[1:].partition(b"\x00")
        if not sep:
            continue
        out.append({
            "origin": origin_bytes.decode("utf-8", "replace"),
            "key": decode(key_bytes),
            "value": decode(record.value),
            "seq": record.seq,
            "state": record.state.name,
        })
    db.close()
    return out


def collect_real_secrets(real_folder):
    """Every real team id, user id, token, name, domain, session id, and any
    other ID-shaped substring found anywhere in the real localConfig_v2 /
    activitySession_* values - a broad net, independent of the generation
    script's own bookkeeping."""
    import re
    id_re = re.compile(r"\b([TUCDG][A-Z0-9]{7,10})\b")
    secrets = set()

    records = read_raw(real_folder)
    for r in records:
        if r["key"] != "localConfig_v2" and not r["key"].startswith("activitySession_"):
            continue
        if r["state"] == "Deleted":
            if r["key"].startswith("activitySession_"):
                secrets.add(r["key"][len("activitySession_"):])
            continue
        try:
            parsed = json.loads(r["value"])
        except Exception:
            continue

        def walk(o):
            if isinstance(o, dict):
                for k, v in o.items():
                    if k in ("token",) and isinstance(v, str):
                        secrets.add(v)
                    if k in ("name",) and isinstance(v, str) and len(v) >= 4:
                        secrets.add(v)
                    if k in ("domain",) and isinstance(v, str) and len(v) >= 4:
                        secrets.add(v)
                    walk(v)
            elif isinstance(o, list):
                for v in o:
                    walk(v)
            elif isinstance(o, str):
                for m in id_re.finditer(o):
                    secrets.add(m.group(1))

        walk(parsed)
        if r["key"].startswith("activitySession_"):
            secrets.add(r["key"][len("activitySession_"):])
            for sid in (parsed.keys() if isinstance(parsed, dict) else []):
                if len(sid) >= 8:
                    secrets.add(sid)

    return {s for s in secrets if len(s) >= 4}


def main(real_folder, anon_folder):
    real_secrets = collect_real_secrets(real_folder)
    print(f"Collected {len(real_secrets)} distinct real secret strings to check for.\n")

    out_records = read_raw(anon_folder)
    print(f"Anonymized output: {len(out_records)} raw records.\n")

    by_key = {}
    for r in out_records:
        by_key.setdefault(r["key"], []).append(r)

    leaks = []
    for key, recs in sorted(by_key.items()):
        print(f"key={key!r}  versions={len(recs)}  states={[r['state'] for r in recs]}")
        for r in recs:
            blob = r["key"] + "\x00" + r["value"]
            if r["state"] != "Deleted":
                try:
                    json.loads(r["value"])
                except Exception as e:
                    print(f"    !! seq={r['seq']} VALUE IS NOT VALID JSON: {e}")
            for secret in real_secrets:
                if secret in blob:
                    leaks.append((key, r["seq"], len(secret)))

    print()
    if leaks:
        print(f"LEAKS FOUND: {len(leaks)}")
        for key, seq, length in leaks:
            print(f"  key={key} seq={seq} secret_len={length}")
        sys.exit(1)
    else:
        print(f"NO LEAKS - none of the {len(real_secrets)} known real secret strings "
              f"appear anywhere in the {len(out_records)}-record anonymized output.")


if __name__ == "__main__":
    real = sys.argv[1] if len(sys.argv) > 1 else "/root/forensic-synth/input/real_slack_leveldb"
    anon = sys.argv[2] if len(sys.argv) > 2 else \
        "/root/forensic-synth/output/anonymized_slack/Slack/Local Storage/leveldb"
    main(real, anon)
